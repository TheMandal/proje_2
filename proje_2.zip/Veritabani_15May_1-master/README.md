# Veritabanı 15 Mayıs 2025  



![gorsel](https://github.com/ezfesoft/Veritabani_15May_1/blob/master/veri_15may_0.PNG))


1- SQL bağlantı cümlesini oluşturun ve textBox içine yazarak "SQL Bağlantısı Kur" butonuna tıklayınız

2- "Tüm Öğrencileri Listele" butonunun çalışması için gerekli SQL kodunu butonun Click olayına ekleyiniz.

3- Ad kutusuna isim girerek "Öğrenci Ara" butonunun çalışması için gerekli SQL kodunu ekleyiniz.

4- "En Genç Öğrenciyi Listele" butonuna basıldığında sıralama yaparak en genç öğrenciyi getiren SQL kodunu butonun olayına ekleyiniz.

5- Bölüm kutusuna bölüm adı girerek "Bölüm Öğrencilerini Getir" butonunun çalışması için gerekli SQL kodunu ekleyiniz.

6- Ad, Soyad, Doğum Tarihi ve Bölüm alanları doldurularak "Öğrenci Ekle" butonunun Click olayına gerekli SQL kodu yazınız.


